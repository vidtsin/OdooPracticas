# -*- coding: utf-8 -*-
{
    'name': 'To-Do App',
    'description': 'Total llibertat i control als usuaris',
    'summary': 'GNU',
    'website': 'http://www.stallman.org/',
    'author': 'El Ritxi Stallman',
    'depends': ['base'],
    'application': True,
    'data': ['views/todo_menu.xml']
}

